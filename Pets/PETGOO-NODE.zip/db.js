var mongoose = require('mongoose');
mongoose.connect('mongodb://guivmartins18:cesusc18@ds143293.mlab.com:43293/aulamongo');
 
var customerSchema = new mongoose.Schema({
    nome: String,
    bairro: String,
    
}, { collection: 'customers' }
);
 
module.exports = { Mongoose: mongoose, CustomerSchema: customerSchema }